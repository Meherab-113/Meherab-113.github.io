#include <iostream>
#include <vector>
#include <fstream>
#include <algorithm>
#include <string>
#include <limits>
#include <ctime>
#include <cstdlib>

using namespace std;

// Class to hold student information
class Student {
public:
    string name;
    int scores[4];  // Scores for Trigonometry, Logarithms, Simple Algebra, and Simple Multiplication and Division
    int totalScore;
    int rank;

    Student(string n) : name(n), totalScore(0), rank(0) {
        fill(begin(scores), end(scores), 0);
    }

    void updateScore(int topic, int points) {
        scores[topic] += points;
        totalScore += points;
    }
};

// Class to handle the quiz functionalities
class Quiz {
private:
    vector<Student> students;

    void loadStudents() {
        ifstream file("students.txt");
        if (file.is_open()) {
            string name;
            int score1, score2, score3, score4, totalScore;
            while (file >> name >> score1 >> score2 >> score3 >> score4 >> totalScore) {
                Student student(name);
                student.scores[0] = score1;
                student.scores[1] = score2;
                student.scores[2] = score3;
                student.scores[3] = score4;
                student.totalScore = totalScore;
                students.push_back(student);
            }
            file.close();
        }
    }

    void saveStudents() {
        ofstream file("students.txt");
        if (file.is_open()) {
            for (auto& student : students) {
                file << student.name << " " << student.scores[0] << " " << student.scores[1] << " "
                     << student.scores[2] << " " << student.scores[3] << " " << student.totalScore << endl;
            }
            file.close();
        }
    }

    void rankStudents() {
        sort(students.begin(), students.end(), [](const Student& a, const Student& b) {
            return a.totalScore > b.totalScore;
        });

        for (size_t i = 0; i < students.size(); ++i) {
            students[i].rank = i + 1;
        }
    }

    int askQuestion(const string& question, float correctAnswer) {
        float answer;
        cout << question;
        while (!(cin >> answer)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }

        if (abs(answer - correctAnswer) < 0.01) { // Allowing a small error margin
            cout << "Correct!\n";
            return 10; // Points for correct answer
        } else {
            cout << "Wrong! The correct answer is: " << correctAnswer << "\n";
            return 0; // No points for incorrect answer
        }
    }

public:
    Quiz() {
        loadStudents();
        srand(static_cast<unsigned int>(time(0))); // Seed for random number generation
    }

    ~Quiz() {
        saveStudents();
    }

    void addStudent(const string& name) {
        students.push_back(Student(name));
    }

    void takeQuiz(const string& studentName) {
        auto it = find_if(students.begin(), students.end(), [&studentName](const Student& s) {
            return s.name == studentName;
        });

        if (it == students.end()) {
            cout << "Student not found." << endl;
            return;
        }

        int topic;
        cout << "Select a quiz topic:\n";
        cout << "1. Trigonometry\n";
        cout << "2. Logarithms\n";
        cout << "3. Simple Algebra\n";
        cout << "4. Simple Multiplication and Division\n";
        cout << "Enter your choice: ";
        cin >> topic;
        topic--;  // Adjust to zero-based index

        if (topic < 0 || topic > 3) {
            cout << "Invalid topic." << endl;
            return;
        }

        // Define questions for each topic
        vector<pair<string, float>> questions;
        if (topic == 0) { // Trigonometry
            questions = {
                {"What is sin(90)? (in degrees) ", 1.0},
                {"What is cos(0)? (in degrees) ", 1.0},
                {"What is tan(45)? (in degrees) ", 1.0},
                {"What is sin(30)? (in degrees) ", 0.5},
                {"What is cos(90)? (in degrees) ", 0.0},
                {"What is tan(0)? (in degrees) ", 0.0},
                {"What is sin(60)? (in degrees) ", 0.866},
                {"What is cos(30)? (in degrees) ", 0.866},
                {"What is tan(60)? (in degrees) ", 1.732},
                {"What is sin(45)? (in degrees) ", 0.707}
            };
        } else if (topic == 1) { // Logarithms
            questions = {
                {"What is log(100)? (base 10) ", 2.0},
                {"What is log(10)? (base 10) ", 1.0},
                {"What is log(1)? (base 10) ", 0.0},
                {"What is log(1000)? (base 10) ", 3.0},
                {"What is log(4)? (base 2) ", 2.0},
                {"What is log(8)? (base 2) ", 3.0},
                {"What is log(16)? (base 2) ", 4.0},
                {"What is log(32)? (base 2) ", 5.0},
                {"What is log(2)? (base 2) ", 1.0},
                {"What is log(64)? (base 2) ", 6.0}
            };
        } else if (topic == 2) { // Simple Algebra
            questions = {
                {"What is 2 + 2? ", 4.0},
                {"What is 3 * 3? ", 9.0},
                {"What is 5 - 3? ", 2.0},
                {"What is 12 / 4? ", 3.0},
                {"What is 7 + 5? ", 12.0},
                {"What is 10 - 6? ", 4.0},
                {"What is 8 * 1? ", 8.0},
                {"What is 20 / 5? ", 4.0},
                {"What is 4 + 4? ", 8.0},
                {"What is 9 - 3? ", 6.0}
            };
        } else if (topic == 3) { // Simple Multiplication and Division
            questions = {
                {"What is 3 * 4? ", 12.0},
                {"What is 6 / 2? ", 3.0},
                {"What is 5 * 5? ", 25.0},
                {"What is 20 / 4? ", 5.0},
                {"What is 8 * 7? ", 56.0},
                {"What is 10 / 5? ", 2.0},
                {"What is 9 * 6? ", 54.0},
                {"What is 12 / 3? ", 4.0},
                {"What is 15 * 2? ", 30.0},
                {"What is 24 / 6? ", 4.0}
            };
        }

        // Shuffle questions and select 10
        random_shuffle(questions.begin(), questions.end());
        int points = 0;
        for (int i = 0; i < 10; ++i) {
            points += askQuestion(questions[i].first, questions[i].second);
        }

        it->updateScore(topic, points);
        rankStudents();

        int choice;
        cout << "1. Exit to main menu\n";
        cout << "2. Retake quiz\n";
        cout << "Enter your choice: ";
        cin >> choice;

        if (choice == 2) {
            takeQuiz(studentName);
        }
    }

    void displayRankings() {
        rankStudents();
        cout << "Rankings:\n";
        for (const auto& student : students) {
            cout << "Name: " << student.name
                 << ", Trigonometry: " << student.scores[0]
                 << ", Logarithms: " << student.scores[1]
                 << ", Simple Algebra: " << student.scores[2]
                 << ", Simple Multiplication and Division: " << student.scores[3]
                 << ", Total Score: " << student.totalScore
                 << ", Rank: " << student.rank << endl;
        }
        cout << "Press Enter to return to the main menu...";
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        cin.get();
    }
};

// Function to display menu
void displayMenu();

int main() {
    Quiz quiz;
    int choice;
    string name;

    while (true) {
        displayMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter student name: ";
            cin >> name;
            quiz.addStudent(name);
            quiz.takeQuiz(name);
            break;
        case 2:
            quiz.displayRankings();
            break;
        case 3:
            cout << "Exiting the program.\n";
            return 0;
        default:
            cout << "Invalid choice. Please try again.\n";
        }
    }
}
void displayMenu() {
    cout << "\n==========================\n";
    cout << "       Learning Mathematics\n";
    cout << "==========================\n";
    cout << "1. Quiz\n";
    cout << "2. Rank\n";
    cout << "3. Exit\n";
    cout << "Enter your choice: ";
}
