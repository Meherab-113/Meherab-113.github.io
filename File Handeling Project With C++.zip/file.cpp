#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

class country {
public:
    string n;
    long p;
    long a;
};

int main() {
    vector<country> enter;
    country c;

    // Option 1: Read from a file
    fstream infile("countries.txt");
    while (infile >> c.n >> c.p >> c.a) {
        enter.push_back(c);
    }
    infile.close();

    // Option 2: Read from user input
 int numCountries;
    cout << "Enter the number of countries: ";
   cin >> numCountries;

 for (int i = 0; i < numCountries; i++) {
     cout << "Enter country name: ";
    cin >> c.n;
     cout << "Enter population: ";
      cin >> c.p;
       cout << "Enter area: ";
     cin >> c.a;

  enter.push_back(c);
   }

    // ... rest of your code
}
